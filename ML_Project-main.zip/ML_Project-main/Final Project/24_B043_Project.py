import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.impute import SimpleImputer

file_path = r"D:\\Machine Learning\\pythonProject\\ML_Project-main\\Final Project\\1970-2023 Oil spill .csv"  # Update this path
try:
    data = pd.read_csv(file_path)
    print("Dataset loaded successfully!")
except FileNotFoundError:
    print("Error: File not found. Please check the file path.")
    exit()


print("Dataset Columns:", data.columns)


required_columns = ['Year', 'Quantity of oil spilled (ton)']
if all(column in data.columns for column in required_columns):

    data = data[required_columns]


    print("\nHandling missing values...")
    missing_values_before = data.isnull().sum()
    print("Missing values before handling:\n", missing_values_before)

    imputer = SimpleImputer(strategy='mean')
    data[['Quantity of oil spilled (ton)']] = imputer.fit_transform(data[['Quantity of oil spilled (ton)']])

    missing_values_after = data.isnull().sum()
    print("Missing values after handling:\n", missing_values_after)


    X = data[['Year']].values
    y = data['Quantity of oil spilled (ton)'].values


    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)


    regressor = LinearRegression()
    regressor.fit(X_train, y_train)


    y_predict = regressor.predict(X_test)

    print("\nOriginal values (Test set):", y_test)
    print("\nPredicted values:", y_predict)


    plt.scatter(X_train, y_train, color='green', label='Training Data')
    plt.plot(X_train, regressor.predict(X_train), color='red', label='Regression Line')
    plt.scatter(X_test, y_test, color='blue', label='Test Data')
    plt.title('Year vs Quantity of Oil Spilled')
    plt.xlabel('Year')
    plt.ylabel('Quantity of Oil Spilled (ton)')
    plt.legend()
    plt.show()


    future_years = np.array(range(2024, 2035)).reshape(-1, 1)  # Predict from 2024 to 2034
    future_predictions = regressor.predict(future_years)

    print("\nPredictions for future years (2024-2034):")
    for year, prediction in zip(future_years.flatten(), future_predictions):
        print(f"Year: {year}, Predicted Quantity of Oil Spilled: {prediction:.2f} tons")

   
    plt.scatter(future_years, future_predictions, color='purple', label='Future Predictions')
    plt.plot(future_years, future_predictions, color='orange', linestyle='--', label='Future Trend')
    plt.title('Predicted Future Oil Spilling')
    plt.xlabel('Year')
    plt.ylabel('Quantity of Oil Spilled (ton)')
    plt.legend()
    plt.show()

else:
    print("Error: Required columns 'Year' and 'Quantity of oil spilled (ton)' are missing from the dataset.")